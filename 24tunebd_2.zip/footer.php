<div class="ad_block"><center><iframe class="adplayTop" src="http://adplay-api.ap-southeast-1.elasticbeanstalk.com/adplayapi?pid=58455c6d5fc12&fp=2&useragent=Opera/9.80 (Android; Opera Mini/7.6.40234/37.9178; U; en) Presto/2.12.423 Version/12.16&pos=1&request=&mode=sdk" width="100%" frameborder="0" style="border:none;height:70px;" scrolling="no" border="0"></iframe></center></div>

<div class="block_fotter">
<div class="footer_left">
<div class="menu-footer-mobile-left-container"><ul id="menu-footer-mobile-left" class="menu"><li id="menu-item-36" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-36"><a href="/about">About Us</a></li>
<li id="menu-item-35" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-35"><a href="/advertise">Advertise</a></li>
<li id="menu-item-34" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-34"><a href="/contact">Contact Us</a></li>
<li id="menu-item-33" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-33"><a href="/terms">Terms of Use</a></li>
</ul></div></div>
<div class="footer_right"><div class="menu-footer-mobile-right-container"><ul id="menu-footer-mobile-right" class="menu"><li id="menu-item-37" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-37"><a href="/rights">User Rights</a></li>
<li id="menu-item-38" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-38"><a href="/privacy">Privacy Policy</a></li>
<li id="menu-item-39" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-39"><a href="/faq">FAQ</a></li>
<li id="menu-item-40" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-40"><a href="/copyright">Copyright issues</a></li>

 <?php
if ( is_user_logged_in() ) {

    $current_user = wp_get_current_user(); 
echo '<li id="menu-item-41" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-41"><a href="/wp-login.php?action=logout">Logout</a> ('.$current_user->display_name.')
</li>';
}
?> 
</ul></div></div>



<center><script type="text/javascript" src="http://widget.supercounters.com/online_i.js"></script><script type="text/javascript">sc_online_i
(1374087,"ffffff","e61c1c");</script></center><div class="switch_pc"><small><?php echo do_shortcode('<a href="http://facebook.com/lx.apple.8"> Dx Ratul®</a>'); ?></small></div></div>
</div>
</body>
</html>
<div class="ad_block"><center><script type="text/javascript" src="http://Popsup.net/adz/union/appwall/adv/javascript/9854"></script></center></div>
<script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=98ft0j2l3b"></script>
