<div class="block_category">
 <h2><?php _e('Categories'); ?></h2>
 <ul><?php wp_list_cats('<li>orderby=name&show_count=1</li>'); ?>
</ul>
</div>
<?php get_footer(); ?>